/**
 * 
 */
/**
 * @author Ricke
 *
 */
module DifferentShapes {
}